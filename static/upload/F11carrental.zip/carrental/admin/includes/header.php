<div class="brand clearfix">
	<style>
.car{
	color:black;
    font-family: '', sans-serif;
	display:flex;
	justify-content:center;
	height:2vh;
	/* background-color:white; */
	
	
}
h1{
	/* background-color:white; */
	font-size:30px;
	font-weight:800;

	
}

	</style>
	<a href="dashboard.php" class="car" style="font-size: 25px;"><h1>Car Rental Portal | Admin Panel</h1></a>  
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			
			<li class="ts-account">
				<a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
					<li><a href="change-password.php">Change Password</a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>
