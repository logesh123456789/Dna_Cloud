
<header>
  <style>
  @keyframes gradient {
    0% {
      background-position: 0% 50%;
    }
    50% {
      background-position: 100% 50%;
    }
    100% {
      background-position: 0% 50%;
    }
  }


#navigation_bar{
  position: sticky;
  top:100;
   /* background: linear-gradient(red, yellow);  */ 
  /* background: linear-gradient(135deg, orange 60%, cyan); */
  background: linear-gradient(to right, red, darkblue);


  
}

  #word {
    /* animation: gradient 4s linear infinite;
    /* text-align:center; */
    /* animation-direction: reverse; */
    margin-top:70px;
    text-shadow:2px 8px linear-gradient(to right,  red,purple,blue);;
    /* font-size: 3em; */
    /* background: linear-gradient(to right, #ff7e5f, #feb47b, #ffdb9e); */
    background: linear-gradient(to right,  red,purple,blue);
    background-size: 200% 200%;
    color: transparent;
    -webkit-background-clip: text;
    background-clip: text;
    animation: gradient 5s linear infinite;

    animation-iteration-count: reverse;
     font-size:60px; 
    font-weight:8000;
  

    font-family: '', sans-serif;

   
			/* font-family: arial, sans-serif;
			-webkit-text-fill-color: transparent;
			background-clip: text;
      -webkit-background-clip:text;
      color:transparent; */

    

  }

    .logo{
margin-top:-75px;
margin-bottom:-80px;
margin-right:20px;
    }
    #img1{
      height:350px;
      /* filter: grayscale(100%);  */
    }
  </style>
  <div class="default-header">
    <div class="container">
      <div class="row">
        <div class="col-sm-3 col-md-2">
          
          <div class="logo">  
            
            
            
            <a href="index.php"><img id="img1"src="assets/images/logo.png" alt="image"/><</a>
          </div>
          
        </div>
        <div class="col-sm-9 col-md-10">
          <div class="header_info">
            <?php
         $sql = "SELECT EmailId,ContactNo from tblcontactusinfo";
         $query = $dbh -> prepare($sql);
         $query->execute();
         $results=$query->fetchAll(PDO::FETCH_OBJ);
         foreach ($results as $result) {
           $email=$result->EmailId;
           $contactno=$result->ContactNo;
          }
          ?>   

<div class="header_widgets">
  <div class="circle_icon"> <i class="fa fa-envelope" aria-hidden="true"></i> </div>
  <p class="uppercase_text">For Support Mail us : </p>
  <a href="mailto:<?php echo htmlentities($email);?>"><?php echo htmlentities($email);?></a> </div>
  <div class="header_widgets">
    <div class="circle_icon"> <i class="fa fa-phone" aria-hidden="true"></i> </div>
    <p class="uppercase_text">Service Helpline Call Us: </p>
    <a href="tel:<?php echo htmlentities($contactno);?>"><?php echo htmlentities($contactno);?></a> </div>
    <div class="social-follow">
      
      </div>
      <?php   if(strlen($_SESSION['login'])==0)
	{	
    ?>
 <div class="login_btn"> <a href="#loginform" class="btn btn-xs uppercase" data-toggle="modal" data-dismiss="modal">Login / Register</a> </div>
 <?php }
else{ 
  
  echo "Welcome To Car rental portal";
} ?>
<h3 id="word">CAR RENTAL PORTAL</h3>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!-- Navigation -->
  <nav id="navigation_bar" class="navbar navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button id="menu_slide" data-target="#navigation" aria-expanded="false" data-toggle="collapse" class="navbar-toggle collapsed" type="button"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>
      <div class="header_wrap">
        <div class="user_login">
          <ul>
            <li class="dropdown"> <a href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user-circle" aria-hidden="true"></i> 
<?php 
$email=$_SESSION['login'];
$sql ="SELECT FullName FROM tblusers WHERE EmailId=:email ";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
	{

	 echo htmlentities($result->FullName); }}?>
   <i class="fa fa-angle-down" aria-hidden="true"></i></a>
              <ul class="dropdown-menu">
           <?php if($_SESSION['login']){?>
            <li><a href="profile.php">Profile Settings</a></li>
              <li><a href="update-password.php">Update Password</a></li>
            <li><a href="my-booking.php">My Booking</a></li>
            <li><a href="post-testimonial.php">Post a Testimonial</a></li>
          <li><a href="my-testimonials.php">My Testimonial</a></li>
            <li><a href="logout.php">Sign Out</a></li>
            <?php } ?>
          </ul>
            </li>
          </ul>
        </div>
        <div class="header_search">
          <div id="search_toggle"><i class="fa fa-search" aria-hidden="true"></i></div>
          <form action="search.php" method="post" id="header-search-form">
            <input type="text" placeholder="Search..." name="searchdata" class="form-control" required="true">
            <button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
          </form>
        </div>
      </div>


      <div class="collapse navbar-collapse" id="navigation">
        <ul class="nav navbar-nav">
          <li><a href="index.php">Home</a>    </li>
          	 
          <li><a href="page.php?type=aboutus">About Us</a></li>
          <li><a href="car-listing.php">Car Listing</a>
          <li><a href="page.php?type=faqs">FAQs</a></li>
          <li><a href="contact-us.php">Contact Us</a></li>

        </ul>
      </div>
    </div>
  </nav>
  <!-- Navigation end --> 
  
</header>